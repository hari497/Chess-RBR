# Chess RBR

Android prototype built with Kotlin and Jetpack Compose.

## Build
GitHub Actions builds a debug APK on every push to `main`. Open Actions, select the latest successful run, and download the `Chess-RBR-debug-apk` artifact.

## Demo
Username `admin`, password `admin123` opens the admin preview. Any other non-empty username and password opens the student preview.

## Important
This is an early UI prototype. Login is not secure, student accounts are not stored, the chessboard does not enforce legal moves, and there is no chess AI or online multiplayer. Do not use real student data until a secure backend is added.
